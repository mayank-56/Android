package com.jaykukadiya.allpractical;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical08Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical08);
        EditText phone = findViewById(R.id.phone);
        Button dial = findViewById(R.id.dial);
        dial.setOnClickListener(v -> {
            String n = phone.getText().toString().trim();
            if (n.isEmpty()) {
                Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
                return;
            }
            Uri uri = Uri.parse("tel:" + Uri.encode(n));
            startActivity(new Intent(Intent.ACTION_DIAL, uri));
        });
    }
}
