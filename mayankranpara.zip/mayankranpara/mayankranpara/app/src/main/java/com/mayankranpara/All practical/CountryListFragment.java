package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * Flag images from <a href="https://flagcdn.com/">flagcdn.com</a> (PNG by ISO country code).
 */
public class CountryListFragment extends Fragment {

    public interface Listener {
        void onCountrySelected(@NonNull String name, @Nullable String flagImageUrl);
    }

    private static final String[] NAMES = {
            "India", "United States", "United Kingdom", "Japan", "France", "Germany"
    };

    /** HTTPS URLs — w160 = width in px for a reasonable size on screen. */
    private static final String[] FLAG_URLS = {
            "https://flagcdn.com/w160/in.png",
            "https://flagcdn.com/w160/us.png",
            "https://flagcdn.com/w160/gb.png",
            "https://flagcdn.com/w160/jp.png",
            "https://flagcdn.com/w160/fr.png",
            "https://flagcdn.com/w160/de.png"
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_country_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ListView list = view.findViewById(R.id.country_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_list_item_1, NAMES);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                if (getActivity() instanceof Listener) {
                    ((Listener) getActivity()).onCountrySelected(NAMES[position], FLAG_URLS[position]);
                }
            }
        });
    }
}
