package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class Practical53Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical53);
        TextView out = findViewById(R.id.json_out);
        Button parse = findViewById(R.id.parse);
        parse.setOnClickListener(v -> {
            try {
                String raw = "{\"course\":\"Android\",\"credits\":4,\"topics\":[\"UI\",\"Storage\",\"Sensors\"]}";
                JSONObject o = new JSONObject(raw);
                String course = o.getString("course");
                int credits = o.getInt("credits");
                JSONArray topics = o.getJSONArray("topics");
                StringBuilder b = new StringBuilder();
                b.append("course=").append(course).append('\n');
                b.append("credits=").append(credits).append('\n');
                b.append("topics=");
                for (int i = 0; i < topics.length(); i++) {
                    b.append(topics.getString(i)).append(i < topics.length() - 1 ? ", " : "");
                }
                out.setText(b.toString());
            } catch (Exception e) {
                out.setText(e.getMessage());
            }
        });
    }
}
