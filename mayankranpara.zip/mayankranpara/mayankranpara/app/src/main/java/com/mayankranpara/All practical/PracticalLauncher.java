package com.jaykukadiya.allpractical;

import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public final class PracticalLauncher {

    public final int number;
    @NonNull
    public final String title;
    @NonNull
    public final Class<? extends AppCompatActivity> activityClass;

    public PracticalLauncher(int number, @NonNull String title,
                             @NonNull Class<? extends AppCompatActivity> activityClass) {
        this.number = number;
        this.title = title;
        this.activityClass = activityClass;
    }

    public Intent intent(@NonNull AppCompatActivity from) {
        return new Intent(from, activityClass);
    }
}
